
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `piezas`
--

CREATE TABLE `piezas` (
  `CODIGO` varchar(6) NOT NULL,
  `NOMBRE` varchar(20) NOT NULL,
  `PRECIO` float NOT NULL,
  `DESCRIPCION` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `piezas`
--

INSERT INTO `piezas` (`CODIGO`, `NOMBRE`, `PRECIO`, `DESCRIPCION`) VALUES
('001', 'pieza1', 12.99, 'pieza frontal'),
('002', 'pieza2', 0.56, 'tornillo');
