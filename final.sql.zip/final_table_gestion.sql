
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gestion`
--

CREATE TABLE `gestion` (
  `CODPROVEEDOR` varchar(6) NOT NULL,
  `CODPIEZA` varchar(6) NOT NULL,
  `CODPROYECTO` varchar(6) NOT NULL,
  `CANTIDAD` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `gestion`
--

INSERT INTO `gestion` (`CODPROVEEDOR`, `CODPIEZA`, `CODPROYECTO`, `CANTIDAD`) VALUES
('p001', '001', 'pr001', 800),
('p002', '002', 'pr002', 58);
