
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

CREATE TABLE `proyectos` (
  `CODIGO` varchar(6) NOT NULL,
  `NOMBRE` varchar(40) NOT NULL,
  `CIUDAD` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `proyectos`
--

INSERT INTO `proyectos` (`CODIGO`, `NOMBRE`, `CIUDAD`) VALUES
('pr001', 'furgoneta electrica', 'vitoria'),
('pr002', 'coche hibrido', 'vitoria');
