
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `gestion`
--
ALTER TABLE `gestion`
  ADD PRIMARY KEY (`CODPROVEEDOR`,`CODPIEZA`,`CODPROYECTO`),
  ADD KEY `CODPIEZA` (`CODPIEZA`),
  ADD KEY `CODPROYECTO` (`CODPROYECTO`);

--
-- Indices de la tabla `piezas`
--
ALTER TABLE `piezas`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Indices de la tabla `proveedores`
--
ALTER TABLE `proveedores`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`CODIGO`);

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `gestion`
--
ALTER TABLE `gestion`
  ADD CONSTRAINT `gestion_ibfk_1` FOREIGN KEY (`CODPROVEEDOR`) REFERENCES `proveedores` (`CODIGO`),
  ADD CONSTRAINT `gestion_ibfk_2` FOREIGN KEY (`CODPIEZA`) REFERENCES `piezas` (`CODIGO`),
  ADD CONSTRAINT `gestion_ibfk_3` FOREIGN KEY (`CODPROYECTO`) REFERENCES `proyectos` (`CODIGO`);
