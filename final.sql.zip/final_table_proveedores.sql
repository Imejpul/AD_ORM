
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proveedores`
--

CREATE TABLE `proveedores` (
  `CODIGO` varchar(6) NOT NULL,
  `NOMBRE` varchar(20) NOT NULL,
  `APELLIDOS` varchar(30) NOT NULL,
  `DIRECCION` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `proveedores`
--

INSERT INTO `proveedores` (`CODIGO`, `NOMBRE`, `APELLIDOS`, `DIRECCION`) VALUES
('p001', 'tornilleria', 'alavesa', 'pol ind uritiasolo'),
('p002', 'ceva', 'termoformado', 'pol ind jundiz');
